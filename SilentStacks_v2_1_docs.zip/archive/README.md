# Archive

This folder holds superseded documentation and specs for traceability.

- v2.0 specs (CT.gov enrichment attempt) — deprecated due to CORS.
- v1.2 docs (production baseline).

Place older files here when discovered; keep `README.md` updated with pointers.
