# Changelog

**Generated:** 2025-08-20 05:00 UTC

## 2.1 (current) — Pivoted bulk ops, CORS-safe, AAA theming
- Carry-forward from 2.0 with major pivot: removed direct ClinicalTrials.gov API calls due to CORS; switched to NCT linkouts discovered via PubMed.
- Bulk Ops hard cutoff 50,000 rows; throttled lookups (≤2/sec); checkpointing + resume; IndexedDB storage; dirty-row highlighting and filters.
- Table/Export headers normalized (NLM strict citation, "n/a" for missing values).
- “Commit Clean” and “Commit All” flows; dirty-only export for offline cleanup.
- Accessibility: WCAG 2.2 AAA baseline; Light/Dark/High-Contrast themes P0.
- Offline-first: service worker + durable queues; session resume for long runs.

## 2.0 (superseded) — Attempted CT.gov v2 integration
- Added CT.gov trial enrichment (phase/status/sponsor) and chips.
- Introduced bulk paste/upload + MeSH chips (partial wiring).
- **Deprecated** due to CT.gov CORS issues and instability. Archived in /archive.

## 1.2 (production baseline)
- Single-entry lookups (PMID/DOI), manual table management, CSV/JSON export.
- Offline support and theming foundation.
