# SilentStacks Developer Guide (v2.1)

## Architecture
- Client-only (no server). IndexedDB for dataset; localStorage for prefs.  
- Service Worker for shell + queue; resumable bulk importer.  
- IIFE modules; event-driven; progressive enhancement.

## APIs
- PubMed eUtils (ESummary + EFetch), CrossRef REST.  
- **No CT.gov API**; create NCT Link when NCT ID present in PubMed metadata.

## Throttling & Checkpoints
- Global limiter ≤2 req/sec.  
- Checkpoint after each batch (e.g., 50 items): `{cursor, successes, errors, time}` in IndexedDB.  
- Resume by reading latest checkpoint and continuing queue.

## Dirty Data
- Validate tokens (PMID/DOI patterns); fuzzy match titles with confidence score.  
- Confidence < threshold → mark dirty; do not autocommit.  
- “n/a” for missing values on insert/export.

## NLM Citation
- Strict formatter; fallbacks for missing fields fill “n/a”.  
- Title exactly as returned by PubMed.  

## Table Insert (prepend) Contract
- Always write full 7 columns; never empty strings.  
- NCT Link is raw URL if NCT present; else “n/a”.

## Storage
- Requests: IndexedDB store `requests` with keyPath `id`.  
- Checkpoints: store `bulkJobs` keyed by jobId.  
- Settings: `silentstacks_settings` in localStorage.

## A11y & Themes
- WCAG 2.2 AAA; keyboard traps forbidden; visible focus.  
- Themes via data attributes; contrast verified.

## Security
- Escape all dynamic HTML; allow-list query params; never store API keys.  
- No public proxies; CORS must be native to API.

