# SilentStacks – Master Playbook v2.1 (Draft)

**Forked from v2.0:** 2025-08-19  
**Status:** Draft; all 2.0 content carried forward then updated.

> This is the authoritative spec for behavior, selectors, and acceptance checks.
> 2.0 is archived; 1.2 is the production baseline for UI contract.

## P0 Scope (must ship)
1) **Client-only architecture** (no server): IndexedDB primary; localStorage for prefs.  
2) **Bulk Ops**: paste/upload, mixed tokens, 50k hard cutoff, ≤2 API calls/sec, checkpoint + resume.  
3) **CORS-safe pivot**: remove CT.gov API; NCT linkouts derived from PubMed.  
4) **AAA accessibility**: WCAG 2.2; Light/Dark/High-Contrast themes.  
5) **Strict table/export headers** with NLM citation; "n/a" for blanks.  
6) **Commit flows**: Commit Clean vs Commit All; dirty-only export.

## UI Contract (unchanged from 1.2 unless stated)
- Preserve IDs/classes/roles/tab structure.  
- Add **NCT Link** column to table (raw URL).  
- Add status region `#ss-live` for aria-live updates.

### Table / Export Headers (authoritative)
| Urgency | Docline # | PMID | Citation | NCT Link | Patron e-mail | Fill Status |
|--------|-----------|------|----------|----------|---------------|-------------|

- **Citation**: strict NLM format (Title as-from PubMed; authors/journal as standardized).  
- **NCT Link**: raw URL, e.g., `https://clinicaltrials.gov/study/NCT01234567`.  
- Any missing value must be written as **n/a** (not empty).

## Single Entry (“Add Request”) — Flow
- Input may be PMID, DOI, or Title.  
- Try PubMed (PMID/title) → CrossRef (DOI) to enrich; cross-check for consistency.  
- If PubMed metadata includes NCT ID(s), synthesize **NCT Link** (no CT.gov fetch).  
- Merge MeSH (≤8) into tags; do not overwrite user input.  
- Save to table immediately (auto-commit), editable post-insert.

## Bulk Operations — Behavior
- Accept: `.txt`, `.csv`, `.json`, or paste (mixed PMIDs/DOIs/Titles).  
- Normalize & dedupe; queue at ≤2/sec; persist state in IndexedDB.  
- **Dirty data handling**: invalid/missing/ambiguous rows flagged; color-coded; filterable.  
- **Commit Clean** adds only validated rows; **Commit All** inserts all but marks dirty.  
- **Export dirty-only** for offline cleanup, then re-import.  
- **Hard cutoff**: 50,000 rows. Reject with explanation and suggest chunking.  

### Worst-Case Scenarios (explicit)
- Paste of 50k mixed noisy tokens; intermittent network loss → importer resumes from last checkpoint.
- Titles-only dump w/ misspellings and diacritics → fuzzy search pass with confidence threshold; <threshold stays dirty.
- Duplicates across files and pastes → stable dedupe with first-seen order preserved.
- Malformed CSV (commas in quoted fields, Excel artifacts) → robust parser + fallback regex.
- 500k attempt → reject at preflight, no memory blowup.
- User closes tab mid-run → index + checkpoint saved; resumes on reopen.

## Accessibility & Theming
- All interactive elements reachable by keyboard; focus rings visible; skip links.  
- Live regions for progress/errors; chip containers labeled; color contrast ≥ AAA.  
- Themes: light/dark/high-contrast; user choice persisted; no info by color alone.

## Security & Data
- Sanitize all inputs/outputs; encode identifiers; allow-listed params.  
- No public proxies; no unsafe CORS workarounds.  
- Error logs capped and scrubbed; no PII in logs.

## Acceptance Checks
- Single PMID populates citation + NCT Link (if present) → row inserted with n/a for missing fields.  
- Bulk paste mixed identifiers → processed in order; dirty rows highlighted; filters work.  
- Checkpoint/resume verified by tab close + reopen.  
- Export (clean-only & full) re-import safe; “n/a” preserved.

## Selector Map (key anchors)
- `#ss-live` (aria-live), `#requests-table tbody` (insert/prepend rows), bulk controls (`#bulk-paste-btn`, `#bulk-upload-btn`), inputs (`#pmid`, `#doi`, `#title`, `#nct`).

