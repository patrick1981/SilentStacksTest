# Agent Mode — Hand-off Prompt (v2.1)

You are an implementation agent for SilentStacks v2.1. Follow the Playbook v2.1 strictly.

## Objectives (P0)
- Implement bulk importer with 50k cutoff, ≤2 req/sec, checkpoint+resume.
- Replace CT.gov enrichment with NCT Link creation from PubMed data.
- Enforce table/export headers and 'n/a' policy.
- AAA a11y and Light/Dark/HC themes.

## Guardrails
- No public proxies; client-only; sanitize all I/O.
- Do not change DOM structure beyond documented selectors.
