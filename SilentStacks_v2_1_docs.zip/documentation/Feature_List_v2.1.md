# SilentStacks Feature Matrix (1.2 → 2.0 → 2.1)

## What stayed (1.2 → 2.1)
- Single-entry lookups (PMID/DOI), table & card views, CSV/JSON export.
- Offline-first shell; theme system; client-only storage.

## Removed / Replaced (2.0 → 2.1)
- CT.gov API enrichment → **Removed** (CORS).  
- Trial details chips → **Replaced** with **NCT Link** (via PubMed-derived IDs).

## New in 2.1
- Bulk Ops hard cutoff 50k; ≤2/sec throttling; checkpoint/resume.  
- Dirty-row handling, filters, Commit Clean/All, dirty-only export.  
- AAA a11y baseline; Light/Dark/HC themes P0.  
- Strict NLM citation + “n/a” policy.

## Columns (authoritative, export mirrors)
Urgency | Docline # | PMID | Citation | NCT Link | Patron e-mail | Fill Status
