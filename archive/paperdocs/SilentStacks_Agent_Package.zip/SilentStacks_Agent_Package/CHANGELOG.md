# Changelog

### [Unreleased]
- seed: add Agent Package (spec, playbooks, checks, scaffold)

### 2025-08-10
- chore(pkg): initial Agent Package
