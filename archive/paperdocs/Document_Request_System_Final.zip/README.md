# 📚 Document Request System (Offline Web App)

A simple, zero-install app for tracking article requests using DOCLINE numbers, PMIDs, and DOIs.

This is designed for librarians and staff who need to manage requests without logging in, installing anything, or learning new systems.

---

## ✅ What the App Can Do

- Add single or bulk article requests
- Auto-fill article info using DOI or PMID
- Works offline, even without internet
- Updates data when user comes back online
- Save filters, search entries, export to CSV
- Auto-saves form drafts
- Print-friendly view
- Modern UI with dark/light mode

---

## 🔗 How Coworkers Use It

**You will send them a link**, like:

```
https://your-username.github.io/your-repo-name/
```

They:
1. Click the link
2. App opens in their browser
3. Use it immediately — no account needed

---

## 🌐 How to Host It (One-Time Setup)

1. Create a GitHub account (if you don’t have one)
2. Create a new repo (e.g., `docline-app`)
3. Upload:
   - `index.html`
   - `README.md`
4. Go to **Settings** → **Pages**
5. Under Source:
   - Select `main` branch
   - Select `/ (root)`
6. Click **Save**

After ~30 seconds, GitHub will show you your site link!

---

## 🧠 Tips

- If coworkers are offline, the app still works — but uses placeholder article data.
- When they come back online, the app asks if they want to update the entries.
- Everything runs in the browser. No data is saved to a server unless exported.
- Encourage coworkers to click **Export CSV** before closing the tab.

---

## 📎 Optional Customizations

- Add your library’s name or logo to the header
- Pre-fill some filters or default fields
- Customize theme colors

---

## ❓ Support

If your staff ever sees errors:
- Ask them to refresh the page
- Or check if they’re online
- You can always export their session or send a fix by replacing the HTML

---

Built to be brain-dead simple. If someone can't use it, they probably shouldn't be requesting DOCLINEs anyway. 😉
