# SilentStacks User Manual

## 🎯 Welcome to SilentStacks
*The intuitive Interlibrary Loan (ILL) request tracking system designed for ease and efficiency.*

---

## 🚀 Getting Started (2 minutes)

### Opening SilentStacks
1. **On a computer**: Double-click the `index.html` file or open your web browser and navigate to the SilentStacks web address
2. **On a tablet/phone**: Tap the bookmark or enter the web address
3. **From a thumb drive**: Plug in the drive, open the folder, double-click `index.html`

### First Look
When SilentStacks opens, you'll see:
- **Navigation tabs** at the top (Dashboard, Add Request, etc.)
- **Dashboard** showing your request statistics
- **Online indicator** in the top-right corner (🌐 Online or 📴 Offline)

**✅ Success Check**: You should see "0 requests" in the statistics boxes.

---

## 📊 Dashboard Overview

The Dashboard is your home base, showing:
- **Total Requests**: All ILL requests you've entered
- **Pending**: Requests still being processed
- **Fulfilled**: Successfully completed requests
- **Follow-up Needed**: Requests requiring attention (after 5 days by default)
- **Recent Requests**: Your 5 most recent entries

**💡 Tip**: Use the Dashboard to quickly check the status of your work.

---

## ➕ Adding New Requests (The Easy Way)

### Step 1: Basic Information
1. Click **"Add Request"** tab
2. You'll see a 3-step progress indicator
3. Start with either:
   - **PMID** (PubMed ID) - like 23842776
   - **DOI** (Digital Object Identifier) - like 10.1038/nature12373
   - **Or just the article title** if you don't have IDs

### Step 2: Automatic Lookup (Magic! ✨)
- **If you have a PMID**: Enter it and click "Lookup" - SilentStacks will automatically fill in the title, authors, journal, and year
- **If you have a DOI**: Enter it and click "Lookup" - Same magic happens
- **If offline**: Don't worry! SilentStacks will remember your lookup and do it when you're back online

### Step 3: Complete the Details
The form automatically moves you through:
1. **Identifiers** (PMID, DOI, or manual entry)
2. **Publication Details** (title, authors, journal, year)
3. **Request Details** (priority, patron info, notes)

### Priority Levels (Important!)
- **🚨 Urgent**: Critical patient care, same-day needed
- **⚡ Rush**: Expedited timeline, within 2-3 days
- **📋 Normal**: Standard processing, 5-7 days

### Saving Your Request
Click **"Save Request"** and you're done! The request appears in your dashboard immediately.

---

## 🔍 Finding and Managing Requests

### Viewing All Requests
1. Click **"All Requests"** tab
2. You'll see all your ILL requests in a list
3. Each request shows:
   - Title and authors
   - Current status
   - Priority level
   - Subject tags (if any)

### Searching for Requests
Use the search box to find requests by:
- Article title
- Author names
- Journal name
- Subject tags
- Patron email
- PMID or DOI

**Example**: Type "cardiology" to find all heart-related requests.

### Filtering Requests
Use the dropdown filters to show only:
- **Status**: Pending, In Progress, Fulfilled, or Cancelled
- **Priority**: Urgent, Rush, or Normal
- **Time**: Today, This Week, This Month, or Overdue
- **Follow-up**: Click "Follow-up Needed" to see requests requiring attention

### Changing Request Status
Click the status dropdown on any request to change it:
- **Pending**: Just submitted, waiting to be processed
- **In Progress**: Actively being worked on
- **Fulfilled**: Successfully completed
- **Cancelled**: Request was withdrawn or cancelled

**💡 Tip**: Change status as you work - it helps track progress and workload.

---

## 🏷️ Using Tags for Organization

### Adding Tags
When creating a request, add tags in the "Subject Tags" field:
- Separate tags with commas: `cardiology, review, urgent`
- Use consistent naming: `surgery` not `Surgery` or `surgical`
