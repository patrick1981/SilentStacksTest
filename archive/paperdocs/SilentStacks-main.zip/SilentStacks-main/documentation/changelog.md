# SilentStacks Changelog

## Version 1.2.0-beta (Current)

### 🎨 Design & Accessibility
- **Reddit Sans Font Integration**: Self-hosted Reddit Sans font for modern, readable typography
- **Enhanced Dark Theme**: Fixed all white background issues, proper contrast ratios
- **High Contrast Mode**: Full WCAG AAA compliance with gold focus indicators
- **Improved Navigation**: Larger touch targets (56px), better spacing, hidden scrollbars
- **Progress Indicator**: Interactive 3-step form progress with clickable navigation

### 🔧 Core Functionality
- **Enhanced API Lookups**: Improved PubMed and CrossRef integration with better error handling
- **Priority System**: Three-tier priority system (Urgent, Rush, Normal) with visual indicators
- **Tag Color Customization**: 8-color palette for categorizing request tags
- **Smart Form Steps**: Auto-advancing form sections based on completion
- **Bulk Paste Import**: Direct CSV import from clipboard with API lookups

### 🌐 Offline Support
- **Offline Manager**: Queue API requests when offline, process when online returns
- **Connection Indicator**: Subtle status indicator showing online/offline state
- **Local Dependencies**: Self-hosted Fuse.js and PapaParse for offline operation
- **Graceful Degradation**: Placeholder data when APIs unavailable

### 📊 Enhanced Request Management
- **Advanced Filtering**: Filter by status, priority, date range, follow-up needs
- **Multi-field Search**: Search across title, authors, journal, tags, notes, IDs
- **Bulk Operations**: Select all/multiple requests, bulk status changes, bulk delete
- **Smart Sorting**: Sort by date, priority, title, journal, status with visual indicators
- **Follow-up Tracking**: Automatic follow-up reminders based on configurable days

### 🔍 User Experience Improvements
- **Mandatory Field Indicators**: Clear required/optional field labeling
- **Form Validation**: Real-time validation with accessibility announcements
- **Keyboard Navigation**: Full keyboard support for all interactive elements
- **Screen Reader Support**: ARIA labels, live regions, semantic markup
- **Mobile Responsive**: Touch-friendly interface, optimized layouts

### 🐛 Bug Fixes
- Fixed white background issues in dark theme
- Corrected event listener reference (`handleImport` vs `handleImportWithLookup`)
- Fixed progress bar hover interference
- Improved connection status positioning
- Enhanced file input visibility across themes

---

## Version 1.1.0
### Features
- Basic ILL request tracking
- PubMed and CrossRef API integration
- CSV/JSON import/export
- Multi-theme support (Light/Dark/High Contrast)
- Search and filtering
- Local storage persistence

---

## Version 1.0.0
### Features
- Initial release
- Basic request form
- Simple request list
- Settings panel
- Theme switching
