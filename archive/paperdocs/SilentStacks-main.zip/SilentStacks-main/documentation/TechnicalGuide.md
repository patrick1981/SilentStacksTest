# SilentStacks Technical Upkeep Guide

## 🎯 Overview
This guide ensures smooth handoff to technical staff and provides maintenance procedures for SilentStacks. Follow these procedures to keep the application running optimally.

---

## 🚨 Immediate Handoff Checklist

### ✅ Pre-Handoff Verification
- [ ] **Application loads correctly** in Chrome, Firefox, Safari, Edge
- [ ] **All tabs navigate properly** (Dashboard, Add Request, All Requests, Import/Export, Settings)
- [ ] **API lookups work** (test with PMID: 23842776 and DOI: 10.1038/nature12373)
- [ ] **Data persists** (add test request, refresh page, verify it remains)
- [ ] **Export functions** (download CSV and JSON, verify data integrity)
- [ ] **Import functions** (upload sample file, verify import success)
- [ ] **All themes work** (Light, Dark, High Contrast)
- [ ] **Offline mode functions** (disconnect internet, verify queuing)

### 📁 File Inventory
Ensure these files are present and correct:
```
silentstacks/
├── index.html (4KB)
├── assets/
│   ├── css/style.css (45KB)
│   ├── js/app.js (75KB)
│   ├── js/offline-manager.js (8KB)
│   └── js/lib/
│       ├── fuse.min.js (25KB)
│       └── papaparse.min.js (45KB)
└── logo/ (various favicon files)
```

### 🔍 Console Error Check
Open browser Developer Tools (F12) → Console tab:
- **No red errors** should appear on page load
- **API calls** should show successful responses
- **Common warning** about favicon.ico is harmless

---

## 📊 Monitoring & Health Checks

### Daily Monitoring (5 minutes)
1. **Open application** in browser
2. **Check connection indicator** (top-right corner)
3. **Test one API lookup** (use PMID: 12345678)
4. **Verify data loads** (check dashboard stats)

### Weekly Monitoring (15 minutes)
1. **Test all API endpoints**:
   - PubMed: Use PMID 23842776
   - CrossRef: Use DOI 10.1038/nature12373
2. **Test import/export**:
   - Export current data as CSV
   - Import sample data
3. **Check all themes**:
   - Light → Dark → High Contrast → Light
4. **Test offline functionality**:
   - Disconnect internet
   - Try API lookup (should queue)
   - Reconnect (should process queue)

### Monthly Deep Check (30 minutes)
1. **Browser compatibility test** across Chrome, Firefox, Safari, Edge
2. **Mobile device testing** (phone/tablet)
3. **Performance check** with browser Lighthouse audit
4. **Data integrity verification** (export all data, check for corruption)
5. **Accessibility audit** using screen reader or accessibility tools

---

## 🔧 Common Issues & Solutions

### Issue: API Lookups Not Working
**Symptoms**: "Lookup failed" error messages, empty results
**Diagnosis**:
```javascript
// Open browser console and test directly:
fetch('https://eutils.ncbi.nlm.nih.gov/entrez/eutils/esummary.fcgi?db=pubmed&id=23842776&retmode=json')
  .then(r => r.json())
  .then(d => console.log(d))
```
**Solutions**:
1. **Check internet connection**
2. **Verify API endpoints** haven't changed
3. **Check for API maintenance** (PubMed status page)
4. **Clear browser cache** (Ctrl+F5 or Cmd+Shift+R)

### Issue: Data Not Saving
**Symptoms**: Requests disappear after refresh, settings reset
**Diagnosis**:
```javascript
// Check localStorage in browser console:
console.log(localStorage.getItem('silentstacks_requests'));
console.log(localStorage.getItem('silentstacks_settings'));
```
**Solutions**:
1. **Check storage quota**: Browser may be out of space
2. **Verify localStorage access**: Private browsing disables it
3. **Clear corrupted data**: Delete and restart if necessary
4. **Export data first**: Always backup before troubleshooting

### Issue: Themes Not Working
**Symptoms**: Colors don't change, dark mode shows white backgrounds
**Diagnosis**:
```javascript
// Check theme attribute:
console.log(document.documentElement.getAttribute('data-theme'));
```
**Solutions**:
1. **Hard refresh**: Ctrl+F5 to reload CSS
2. **Check CSS file**: Ensure style.css loads completely
3. **Clear browser cache**: May have old CSS cached
4. **Reset settings**: Delete settings from localStorage if corrupted

### Issue: Import/Export Problems
**Symptoms**: Files don't download, imports fail
**Diagnosis**: Check browser console for file-related errors
**Solutions**:
1. **Check file permissions**: Ensure download folder is writable
2. **Verify file format**: CSV must have proper headers
3. **File size limits**: Large files may cause browser issues
4. **Pop-up blockers**: May prevent download dialogs

---

## 📈 Performance Optimization

### Regular Maintenance Tasks

#### Every 3 Months:
1. **Clear old data**:
   - Export all data as backup
   - Archive fulfilled requests older than 1 year
   - Clean up unused tags

2. **Update dependencies**:
   - Check for Fuse.js updates
   - Check for PapaParse updates
   - Update favicon if needed

3. **Performance audit**:
   - Run Lighthouse performance test
   - Check for memory leaks (leave app open 24 hours)
   - Monitor file sizes

#### Every 6 Months:
1. **Full system backup**:
   - Export all data
   - Copy all application files
   - Document any customizations

2. **Security review**:
   - Check for new browser security features
   - Review API endpoints for HTTPS compliance
   - Update documentation

### Storage Management
- **Monitor usage**: Check localStorage size regularly
- **Set limits**: Consider max 1000 requests per database
- **Archive strategy**: Move old requests to separate files
- **Backup frequency**: Weekly for active systems

---

## 🔄 Update Procedures

### Minor Updates (Bug fixes, small features)
1. **Backup current version**:
   ```bash
   cp -r silentstacks silentstacks-backup-$(date +%Y%m%d)
   ```

2. **Test update** in separate folder first

3. **Replace files** one at a time:
   - Update `app.js` OR `style.css` OR `index.html`
   - Test after each file replacement
   - Roll back if issues appear

4. **Verify functionality** with test request

### Major Updates (New features, API changes)
1. **Full system backup** including data export

2. **Stage update** in test environment

3. **Incremental deployment**:
   - Deploy to test users first
   - Monitor for 1 week
   - Deploy to all users

4. **Post-update verification**:
   - Test all major functions
   - Check data integrity
   - Monitor error logs

---

## 🚨 Emergency Procedures

### Application Won't Load
1. **Check browser console** for errors
2. **Try different browser** to isolate issue
3. **Revert to backup version** if available
4. **Use basic HTML fallback** for critical access

### Data Corruption
1. **Stop using application** immediately
2. **Export whatever data is accessible**
3. **Restore from most recent backup**
4. **Investigate corruption cause** before resuming

### API Service Outage
1. **Switch to offline mode** (automatic)
2. **Inform users** of temporary limitation
3. **Monitor API status pages**:
   - PubMed: https://www.ncbi.nlm.nih.gov/
   - CrossRef: https://status.crossref.org/
4. **Resume when services restored**

---

## 📞 Support Contacts & Resources

### Technical Resources
- **PubMed API Documentation**: https://www.ncbi.nlm.nih.gov/books/NBK25501/
- **CrossRef API Documentation**: https://github.com/CrossRef/rest-api-doc
- **Fuse.js Documentation**: https://fusejs.io/
- **PapaParse Documentation**: https://www.papaparse.com/docs

### Browser Support
- **Chrome**: Latest 2 versions (primary testing)
- **Firefox**: Latest 2 versions
- **Safari**: Latest 2 versions
- **Edge**: Latest 2 versions

### API Status Pages
- **PubMed/NCBI**: https://www.ncbi.nlm.nih.gov/
- **CrossRef**: https://status.crossref.org/

---

## 📋 Maintenance Log Template

Keep a simple log of maintenance activities:

```
Date: 2024-01-15
Performed by: [Name]
Action: Weekly health check
Results: All systems operational
API Response Times: PubMed <2s, CrossRef <1s
Notes: No issues found

Date: 2024-01-22
Performed by: [Name]
Action: Updated Fuse.js to v6.6.2
Results: Search performance improved
Issues: None
Notes: Backward compatible update
```

---

## 🎓 Knowledge Transfer

### Key Concepts for New Technical Staff
1. **Client-side only**: No server required, runs in browser
2. **Offline-first**: Designed to work without internet
3. **Progressive enhancement**: Works without JavaScript, better with it
4. **Accessibility focused**: WCAG AAA compliance target
5. **Mobile responsive**: Touch-friendly interface

### Training Sequence for Handoff
1. **Day 1**: Overview and architecture walkthrough
2. **Day 2**: API integration and debugging
3. **Day 3**: Data management and storage
4. **Day 4**: UI/UX and theme system
5. **Day 5**: Deployment and maintenance procedures

---

*This upkeep guide ensures SilentStacks remains stable and functional for years to come. Update this document as procedures change or new issues are discovered.*
