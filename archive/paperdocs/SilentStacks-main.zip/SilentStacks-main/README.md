# 📦 SilentStacks Beta

A lightweight, librarian-facing ILL tracking tool for managing DOCLINE, PubMed, and DOI-based systematic review requests — fully local, API-enhanced, and tailored for small teams with no server infrastructure. 
The app is self-contained, fully browser-based, and runs without any server-side components, making it ideal for GitHub Pages, SharePoint environments, or USB use.
It’s fast, secure, and requires no server or login. 

Just click and go.

---

## ⚙️ Features

| Feature                             | Description                                                                 |
| ----------------------------------- | --------------------------------------------------------------------------- |
| **🔍 Smart Lookup**                 | PMID (PubMed) and DOI (Crossref) metadata auto-population.                  |
| **📥 Bulk Upload**                  | Supports CSV and JSON import with queued metadata resolution.               |
| **📌 Follow-Up Flags**              | 🔔 Automatically flags requests 5 days after DOCLINE is populated.          |
| **🧠 Advanced Filters**             | Search/filter by PMID, DOI, DOCLINE (e.g., "show all starting with 138...") |
| **🏷️ Tagging System**              | Add and filter requests by custom tags (e.g., SR, urgent, filled).          |
| **🧩 Tooltip Icons**                | ❓ Icons help users understand field usage (e.g., DOCLINE, DOI).             |
| **💾 Import/Export Support**        | Save/load tracking data via CSV or JSON — work offline or across sessions.  |
| **🎨 SB Admin Visual Style**        | Custom CSS mimics the SB Admin Bootstrap theme (no Bootstrap dependency).   |
| **📎 Manual Status Tracking**       | Track request statuses manually using dropdowns or tags.                    |
| **📂 Runs Locally or GitHub Pages** | Fully static HTML/JS. No server, backend, or account required.              |

## 🚀 Getting Started

You can download the pre-built `silentstacks_codex.zip` directly from the GitHub repository: `https://github.com/patrick1981/SilentStacks/raw/main/silentstacks_codex.zip`.

---

## 🚧 Beta Roadmap

* ✅ Internal tracking system (CRUD)
* ✅ Metadata population via DOI or PMID
* ✅ Follow-up alert (5 days after DOCLINE filled)
* ✅ Filter/search by DOI, PMID, and DOCLINE
* ✅ Import/export (CSV/JSON)
* ✅ Tagging, tooltip system
* ✅ SB Admin–inspired visual theme
* ✅ Local + GitHub Pages–friendly architecture

---

## 📝 Developer Notes

- SB Admin aesthetic mimicked via **custom CSS**, not dependent on Bootstrap.
- All files are **vanilla JS**, commented for clarity.
- Full support for: `CSV` & `JSON` input/output, filter persistence, tooltip hints.
- LocalStorage used for temporary session data (optional).

## 🔐 API Use & Rate Limits

- **PMID lookups:** Uses NCBI E-utilities.
- **DOI lookups:** Uses Crossref API.
- **Rate-limiting:** All external calls throttled to **2 requests per second**.

---

## 🔄 Planned Features (Roadmap)

| Feature                     | Status         |
|----------------------------|----------------|
| **DOCLINE Status Check**   | 🔜 Future Beta  |
| **Batch Lookup by DOCLINE**| 🔜 Future Beta  |
| **Custom Filter Presets**  | ✅ In Progress  |
| **DOCLINE Metadata Import**| 🔜 Planned      |

---

## 🚫 Out of Scope (Beta)

* No multi-user or server-side support.
* No link resolver compatibility.
* No institutional authentication.
* No backend; all features run 100% locally or via GitHub Pages.

---

## 📜 Constraints & Licensing

* 🪪 **MIT License** – Free for reuse, modification, and distribution.
* 🧷 App must run client-side only (local machine or GitHub Pages).
* 🔐 **User is responsible for obtaining API keys from:**

  * [NCBI E-utilities (PubMed)](https://www.ncbi.nlm.nih.gov/books/NBK25501/)
  * [Crossref REST API](https://www.crossref.org/documentation/retrieve-metadata/rest-api/)
* 🚫 If no API keys are entered, the app will restrict access to public Crossref endpoints only.
* 🚦All API calls are throttled to 2 requests/second for compliance.

---

## 🧰 Developer Notes

* Written in 100% vanilla JavaScript (no frameworks).
* Custom CSS mimics Bootstrap (no dependency on external CSS libraries).
* Robust inline code comments included.
* Demo data and dev-friendly examples included in ZIP.
* Supports GitHub Pages, SharePoint, or offline USB usage.
* Intended for small libraries or individuals without IT backend support.

---

## 📈 README Updates

This README will evolve with feature additions. All official updates to features, constraints, and integrations will be reflected here and in the included `/docs` HTML copies.

---

## 👨‍💻 Credits

Built with angst, love, and curiosity by **McDuffkins**.
Gracias to Zoe, Marble, café con leche, and café cubano — por todo.

---

*Request. Track. Fulfilled.*
