(() => {
  console.debug("documentation.js stub loaded – v1.2 UI preserved");
})();
