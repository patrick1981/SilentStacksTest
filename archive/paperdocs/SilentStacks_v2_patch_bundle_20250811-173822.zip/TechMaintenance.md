# TechMaintenance — 20250811-173822
- Serve over http(s) for SW
- Bump CACHE_NAME to purge
- Exporter fallback localStorage key `silentstacks_requests`
