# QuickStart — SilentStacks v2.0 (Patched 20250811-173822)
- SW registration + offline cache
- NLM export (Ctrl/Cmd+E)
- MeSH chips helper
- CT.gov helper
- Cross-pop helper
