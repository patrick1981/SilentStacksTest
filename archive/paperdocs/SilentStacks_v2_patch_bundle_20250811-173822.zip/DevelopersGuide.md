# DevelopersGuide — 20250811-173822
APIs: formatNLMCitation, exportNLM, createMeshChips, fetchClinicalTrial, crossPopulateIdentifiers under window.silentStacksV2.
