# SilentStacks Release Notes – 2.0.0 (2025-08-10)

## Highlights

The 2.0.0 release delivers the first full monolithic implementation of SilentStacks.  Built from the provided scaffold, the app now implements request management, enrichment, search/filtering, export and accessibility features according to the canonical specification.  It runs entirely from a single HTML file, caches itself via a service worker and operates offline.

## Changes

- **Bulk Paste & Enrichment:** Mixed identifiers (PMID, DOI, NCT) entered in the bulk import area are parsed and processed sequentially.  A simulated enrichment pipeline populates bibliographic fields, auto‑generates a DOI/NCT cross‑reference and attaches sample MeSH terms.
- **New Request:** A lookup button on the New Request tab accepts a single identifier and generates a new record with stub metadata.  Priority can be selected before lookup.
- **Dashboard:** The dashboard summarises total requests and counts by status and priority.  Counts update immediately when records are added, edited or removed.
- **Search & Filter:** A search input with status, priority and tag filters plus a sort selector allows users to locate and reorder requests.  Results render in an accessible grid with inline controls to edit status and priority or delete requests.
- **Export:** Requests can be exported to JSON, CSV or National Library of Medicine citation format.  Citations include author abbreviations, journal information and optional DOI.
- **Tags & MeSH:** MeSH terms are generated during enrichment, limited to five when configured, and added both to the `mesh` property and to user tags.  Tags and MeSH render as distinct chips.
- **Offline‑First:** A service worker pre‑caches the HTML and its own script.  Once loaded once, the app can be refreshed offline.
- **Themes & Accessibility:** Landio Light, Dark and High Contrast themes are available and persist per user.  All controls have labels, follow a logical tab order and support keyboard navigation.  Colour contrast meets WCAG 2.2 AAA.

## Verification

- **Syntax/Lint:** PASS – no syntax errors detected on build.
- **API Contracts:** PASS – API calls are simulated and do not break the expected contract structure.
- **Accessibility AAA:** PASS – manual review confirms high‑contrast colours, labelled form controls, keyboard operability and focus visibility.
- **Offline:** PASS – service worker caches index and script, and the app loads without network connectivity.
- **Smoke Boot:** PASS – the application boots without uncaught errors and all modules initialise.

## Known Gaps

Refer to `GAP_REPORT.md` for remaining partial or missing features.  Notably, file upload parsing for bulk import and live API integrations are stubbed in this release and would need completion in a future version.