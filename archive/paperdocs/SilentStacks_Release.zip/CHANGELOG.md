# Changelog

### [2.0.0] – 2025-08-10
* feat: complete monolithic implementation according to SILENTSTACKS_SPEC.md
* feat: bulk paste parsing and simulated enrichment for PMID/DOI/NCT
* feat: export to JSON, CSV, and NLM citation formats
* feat: editable status and priority with counts on dashboard
* feat: search, filter, and sort requests with tag chips
* feat: service worker for offline-first caching
* feat: theme selector for Landio light/dark/high-contrast with persistence
* feat: WCAG 2.2 AAA friendly UI with keyboard navigation, labels, high-contrast themes, and visible focus rings

### [Unreleased]
- seed: add Agent Package (spec, playbooks, checks, scaffold)

### 2025-08-10
- chore(pkg): initial Agent Package
