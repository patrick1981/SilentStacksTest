# SilentStacks Changelog

## Version 2.0.0 (August 11 2025) – “Monolithic v2 Foundations (Incomplete)”

### 🎉 Major Features Added
* **Table View & Toggle:** Added a compact table view for the All Requests page, complete with columns: **Urgency**, **Docline Number**, **PMID**, **Citation**, **Patron Name**, and **Status**.  Users can toggle between the original card layout and the new table view via a button in the results toolbar.  The table is dynamically populated and supports status updates.
* **Bulk Import & Enrichment (alpha):** Introduced scaffolding for pasting or uploading lists of PMIDs.  A new module (`assets/js/v2_features.js`) normalizes bulk input (PMID‑only in this build), enriches each article via PubMed, and appends the results to the request store.  Stubs for CrossRef and ClinicalTrials.gov are in place for upcoming releases.
* **PubMed Enrichment & MeSH Chips:** Added rate‑limited metadata retrieval including title, authors, journal, year, DOI, and up to five MeSH terms per record.  In the table view, retrieved MeSH terms are displayed as lightweight chips within the Citation column.  Results align with the canonical `Request` model defined in `SILENTSTACKS_SPEC.md`.
* **Global API Surface:** Exposed a `silentStacksV2` object on `window` to facilitate integration with the existing UI, providing `parseBulkInput()`, `enrichIdentifiers()`, and `renderTable()` helpers.

### 🛠️ Changes
* Added new markup for the table view and a toggle button in `index.html`.  These changes are strictly additive and preserve all existing IDs, classes, and navigation structures.
* Injected lightweight styles for MeSH chips at runtime instead of altering `style.css`, preserving the read‑only CSS contract.
* Updated documentation and developer guides to reflect the new table view and MeSH chip features.

### 📋 Notes
- This version should be considered **incomplete**.  Only partial scaffolding for PubMed enrichment and a placeholder table view toggle have been delivered.  Required features such as NCT detection and enrichment, CrossRef DOI enrichment, MeSH tag editing, dual import modes, post‑import gap filling, and full table/card parity remain unimplemented.  The wireframe mockups generated in this release omitted required columns and a status indicator, and acceptance tests have not been executed.  Further work is needed to comply with the v2.0 specification.


## Version 1.5.0 (January 2025) - "Complete Clinical Integration"

### 🎉 Major Features Added
- **Complete MeSH Headings Integration**: Restored full Medical Subject Headings with major/minor topic indicators
- **Enhanced Clinical Trials Discovery**: Automatic NCT number extraction and ClinicalTrials.gov API integration
- **Advanced PMID Processing**: Multi-strategy clinical trial detection from abstracts and data banks
- **Publication Type Classification**: Identifies randomized controlled trials and clinical studies

### 🐛 Critical Bug Fixes
- **FIXED**: Export declaration errors in integrated documentation
- **FIXED**: Missing `getFilteredRequests()` function in SearchFilter module
- **FIXED**: Bulk paste textarea element not found errors
- **FIXED**: SearchFilter `initFuse` undefined errors
- **FIXED**: Module loading duplication and initialization issues
- **FIXED**: All console JavaScript errors resolved

### ⚡ Performance Improvements
- Enhanced API retry logic with exponential backoff
- Improved error handling for network timeouts
- Better memory management for large datasets
- Rate limiting compliance for PubMed API calls

### 🎨 UI/UX Enhancements
- MeSH terms display with clickable tags and major topic highlighting
- Clinical trials cards with enhanced details (phases, sponsors, enrollment)
- Auto-filled form field highlighting with visual feedback
- Improved loading states and progress indicators

### 🔬 Medical Research Features
- **Publication Type Detection**: Identifies clinical trials, RCTs, meta-analyses
- **Clinical Trial Linking**: Connects PMIDs to ClinicalTrials.gov records
- **Enhanced Medical Classification**: Study types, evidence levels, phases
- **Sponsor and Enrollment Data**: Complete clinical trial metadata

---

## Version 1.4.0 (December 2024) - "Bulk Operations Overhaul"

### 🚀 New Features
- **Working CSV Upload**: Fixed non-functional CSV file processing
- **PMID Batch Processing**: Bulk import with automatic metadata fetching
- **Enhanced Export Format**: DOCLINE-first CSV export for institutional compatibility
- **Bulk Update Operations**: Select multiple requests for status/priority updates

### 🔧 Fixes
- **FIXED**: CSV upload button functionality
- **FIXED**: Bulk imported requests now appear immediately in All Requests
- **FIXED**: Export headers reordered to match institutional requirements
- **FIXED**: Progress tracking for large batch operations
- **FIXED**: Memory leaks during bulk processing

### 📊 Data Management
- **DOCLINE Integration**: Enhanced support for DOCLINE + PMID workflows
- **Batch Validation**: Input validation for CSV and text imports
- **Error Reporting**: Detailed success/failure reporting for bulk operations
- **Technology Agnostic**: Pure CSV format removes Excel dependencies

### 🎯 Workflow Improvements
- Real-time progress tracking during bulk imports
- Enhanced error messages with specific line/row indicators
- Confirmation dialogs for bulk operations
- Status indicators for all bulk processes

---

## Version 1.3.0 (November 2024) - "Search & Sort Revolution"

### ✨ Major Functionality Restored
- **FIXED**: Sort buttons now functional with visual indicators (↑↓)
- **FIXED**: Delete operations (both individual and bulk) working properly
- **FIXED**: Select All checkbox functionality restored
- **ENHANCED**: Fuse.js integration for fuzzy search capabilities

### 🔍 Search Enhancements
- **Advanced Search**: Full-text search across all request fields
- **Smart Filtering**: Status and priority filtering with search preservation
- **Relevance Scoring**: Search results ranked by relevance percentage
- **Search History**: Query persistence during navigation

### 🗑️ Delete Operations
- **Individual Delete**: Single request deletion with confirmation
- **Bulk Delete**: Multi-select deletion with batch confirmation
- **Selection Tracking**: Proper checkbox state management
- **UI Feedback**: Clear selection counts and status indicators

### 📈 Sorting System
- **Multi-Field Sorting**: Date, Priority, Title, Journal, Status
- **Visual Indicators**: Clear sort direction arrows
- **Sort Persistence**: Maintains sort state during searches
- **Priority Logic**: Intelligent priority ordering (Urgent → Rush → Normal → Low)

---

## Version 1.2.1 (October 2024) - "Stability Foundation"

### 🛠️ Core Infrastructure
- **Enhanced Data Manager**: Improved request storage and retrieval
- **API Rate Limiting**: PubMed API compliance implementation
- **Error Recovery**: Better handling of network failures
- **Memory Optimization**: Reduced browser storage usage

### 🔒 Data Integrity
- **Request Validation**: Enhanced form validation for all fields
- **Data Persistence**: Improved localStorage management
- **Backup Systems**: Automatic data backup before operations
- **Conflict Resolution**: Better handling of duplicate requests

### 🌐 Cross-Platform
- **Mobile Responsiveness**: Improved tablet and mobile layouts
- **Browser Compatibility**: Enhanced support for all major browsers
- **Offline Handling**: Better behavior when network is unavailable
- **Performance**: Faster load times and smoother interactions

---

## Migration Guide: v1.2.1 → v1.5

### Required Updates
1. **JavaScript Modules** (4 files):
   - `assets/js/integrated-documentation.js`
   - `assets/js/modules/search-filter.js`
   - `assets/js/modules/bulk-operations.js`
   - `assets/js/modules/api-integration.js`

2. **HTML Updates**:
   - Replace bulk operations tab content with fixed element IDs

3. **CSS Additions**:
   - Add bulk operations CSS to `enhanced-components.css`
   - Add MeSH headings CSS to `enhanced-components.css`

### Breaking Changes
- **Removed**: Excel file support (technology-agnostic approach)
- **Changed**: Export CSV format now DOCLINE-first
- **Updated**: All element IDs in bulk operations for consistency

### New Requirements
- **MeSH Display Elements**: Add MeSH section to form HTML
- **Clinical Trials Section**: Add clinical trials display area
- **Status Indicators**: Enhanced status elements for API feedback

---

## Testing Checklist

### v1.5 Verification
- [ ] **PMID 16979104**: Should return complete metadata + MeSH + clinical trials
- [ ] **MeSH Headings**: Displayed with major topic indicators (*)
- [ ] **Clinical Trials**: ClinicalTrials.gov integration working
- [ ] **Sort Functions**: All sort buttons working with visual feedback
- [ ] **Delete Functions**: Individual and bulk delete operational
- [ ] **Bulk Import**: PMID batch processing with metadata fetch
- [ ] **CSV Upload**: File upload with progress tracking
- [ ] **No Console Errors**: All JavaScript errors resolved

### Performance Benchmarks
- **Small Batch (5 PMIDs)**: ~15 seconds with full metadata
- **Medium Batch (20 PMIDs)**: ~60 seconds with rate limiting
- **Large Dataset (100+ requests)**: Smooth sorting and searching
- **Mobile Performance**: Responsive on tablets and phones
