# SilentStacks v2.0 Handoff Instructions

## Overview

This project aims to deliver a v2.0 release of SilentStacks, building on the v1.2 baseline.  The v2.0 spec includes major enhancements such as bulk import with PubMed/CrossRef/ClinicalTrials.gov enrichment, editable MeSH tags, dual import modes (PMID and CSV/JSON), post‑import gap filling, a table view with specific column order, AAA accessibility, and offline queueing.  The current work has laid some groundwork but has not yet implemented most of these features.

## Completed Work

* **Baseline Verification:** Ensured there are no structural differences between the v1.2 UI and the current branch.  The DOM IDs, classes, ARIA attributes, and tab structure remain intact.  Screenshots of each section (Dashboard, Add Request, All Requests, Import/Export, Settings) have been captured and are referenced in `RELEASE_NOTES.md`.
* **Monolith Build:** A script (`generate_monolith.py`) was created to inline all CSS and JavaScript into a single HTML file (`dist/SilentStacks_v2_monolith.html`).  The build runs without external dependencies and preserves the original UI.
* **PubMed Enrichment Scaffolding:** A new module (`assets/js/v2_features.js`) normalizes bulk input, applies rate‑limited PubMed enrichment, and appends new records to the request store.  The module exposes functions on the global `silentStacksV2` object.
* **Initial Toggle for Table View:** A table view toggle and placeholder markup were added to `index.html`.  This view is not fully implemented and lacks several required columns.
* **Documentation Updates:** The `QuickStart.md`, `TechMaintenance.md`, `DevelopersGuide.md`, and `changelog.md` were updated with notes about the current build.
* **Gap Analysis:** A detailed `GAP_REPORT.md` (attached) outlines the differences between the v2.0 spec and the current implementation.

## Outstanding Tasks

The following tasks remain to achieve full compliance with the v2.0 specification:

1. **Complete API Integration:**
   * **CrossRef DOI enrichment** – Implement `fetchCrossRefRecord()` to fetch bibliographic data via CrossRef.
   * **ClinicalTrials.gov NCT detection & enrichment** – Detect NCT IDs in user input and in imported PubMed abstracts, and fetch trial metadata via the CT.gov API.
   * **Conflict handling** – Merge and record conflicting fields in `sourceConflicts` as per the spec.

2. **Dual Import Modes:**
   * Implement parsing for CSV and JSON uploads with both minimal seeds and fully populated records.
   * Provide post‑import bulk update and gap‑filling capabilities (edit multiple records at once, fill missing Docline numbers, statuses, etc.).

3. **Table & Card Parity:**
   * Finalize the All Requests table with columns ordered exactly as `Urgency | Docline Number | PMID | Citation | Patron E‑mail | Status | Date Stamp`.
   * Mirror all displayed data between the card view and the table view, including status updates and tags.
   * Integrate sorting, filtering, and search into both views.

4. **MeSH & User Tags:**
   * Display up to five major/minor MeSH terms as chips on each card and row.
   * Allow users to add, edit, and remove custom tags; store them in `Request.tags`.

5. **NCT Section on Add Request:**
   * Add an input or detection mechanism for NCT identifiers on the Add Request page.
   * Automatically fetch CT.gov data when an NCT is entered.

6. **Export & Offline Enhancements:**
   * Update CSV and JSON exports to include enriched fields and tags.
   * Implement an offline queue to capture API calls and edits when the network is unavailable, synchronizing them when connectivity is restored.

7. **Accessibility (WCAG 2.2 AAA):**
   * Audit and correct all new UI elements for AAA compliance: proper labels, high contrast, keyboard navigation, skip links, etc.
   * Test all flows (bulk paste, import, edit, export) with keyboard only.

8. **Run Acceptance Tests:**
   * Execute the test suites referenced in `CHECKS.yml` (syntax, API contracts, accessibility, offline).  Resolve any failures.

## Files & Artifacts

* `GAP_REPORT.md` – A detailed gap analysis of the current build versus the v2.0 specification.  The current version of this file is included in the handoff package.
* `changelog.md` – The changelog has been updated to indicate that the v2.0 foundation is incomplete.  A new entry should be added once the remaining features are implemented.
* `RELEASE_NOTES.md` – Includes baseline verification and screenshot references.  Replace placeholder image IDs with actual file attachments in your next build.
* `v2_features.js` – Contains current enrichment scaffolding.  Expand this file to implement CrossRef and CT.gov enrichment, dual import parsing, and tag management.
* `generate_monolith.py` – Script to inline assets into a single HTML file.

## Next Steps

1. Prioritize completing the enrichment pipeline (CrossRef and CT.gov) with proper rate limiting and caching.
2. Implement the full table and tag features as per the spec, ensuring the card view and table remain in sync.
3. Integrate CSV/JSON import and export features and support offline queueing for all network operations.
4. Conduct a thorough accessibility audit and fix any issues uncovered.
5. Run and pass all acceptance tests described in the Master GAP report.

Please refer to the Master Playbook and Master GAP report for detailed requirements and acceptance criteria.