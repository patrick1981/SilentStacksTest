// documentation.js - no-op stub for v1.2 → v2.0 migration
(() => {
  console.debug("documentation.js stub loaded – v1.2 UI preserved");
})();