# Agent Playbook: Preserve v1.2 UI, Implement v2.0 Features

**Source of truth for UI:** https://patrick1981.github.io/SilentStacks/  
**Reference bundle:** this ZIP (index.html, style.css, app.js, offline-manager.js, fuse.min.js, papaparse.min.js, documentation.js)

## 0) Non-Negotiable Constraints (UI Contract)
- No frameworks added (no Bootstrap/Tailwind/CDNs).
- Do not change existing IDs, classes, or ARIA roles; no tab markup changes.
- Add new behavior via adapter modules or data attributes—do not restructure HTML.
- Missing files (e.g., documentation.js) are already stubbed here.
- Any DOM change requires a before/after screenshot and explicit approval.

## 1) Phased Roadmap (v1.2 → v2.0)
**Phase A — Hardening & Parity**
1. Add service worker + cache manifest (no visual changes).
2. Add error boundary/notifications (use aria-live region).
3. Implement exporters (JSON/CSV/NLM) behind existing Export buttons.
4. Tests: no uncaught errors on boot; keyboard traversal across all tabs.

**Phase B — Enrichment & Cross-Population**
1. API clients (PubMed, CrossRef, ClinicalTrials) with rate limits (PubMed ≤2/sec, CrossRef ≤5/sec, CT.gov 1/sec).
2. Bulk Paste / Bulk Upload normalization for mixed IDs (PMID/DOI/NCT).
3. Cross-populate identifiers; merge sources; log `sourceConflicts`.
4. MeSH auto-tagging (max 5) render as existing tag chips.

**Phase C — Accessibility (WCAG 2.2 AAA)**
1. Theme toggle (Light/Dark/HC) via settings; persist to localStorage.
2. Ensure labels, name/role/value, 7:1 contrast, skip links, visible focus.
3. Keyboard-only passes for core flows.

**Phase D — Offline-First Behaviors**
1. Queue lookups/exports while offline; retry on reconnect.
2. Verify monolith loads offline after first visit; cache integrity check.

**Phase E — Search/Filter Upgrades**
1. Keep Fuse.js; add fielded search + ranking (no visual changes).
2. Preserve table; add sorting/filtering bound to current headers/inputs.

## 2) Data & API Mapping
- Record: id, timestamps, identifiers {pmid, doi, nct}, title, authors, journal, year, vol/issue/pages, abstract, mesh[], tags[], status, priority, notes, sources{pubmed,crossref,clinicaltrials}, sourceConflicts{}.
- NLM export (per-record and bulk); prefer NLM journal abbreviation when available.
- Retries with exp. backoff; 30s timeouts; user-facing notifications.

## 3) Code Organization (no DOM edits)
- `assets/js/adapters/ui-bridge.js` — binds to existing DOM; exposes `onLookup`, `onBulkProcess`, `onExport`.
- `assets/js/api/clients.js` — `fetchPubMed`, `fetchCrossRef`, `fetchCT` with rate-limit gates.
- `assets/js/enrichment/pipeline.js` — Normalize → Fetch → Merge → Cross-populate → Tag MeSH → emit `record:updated`.
- `assets/js/exporters/` — `toJSON`, `toCSV`, `toNLM`.
- `assets/js/offline/sw.js` — service worker (registered by offline-manager.js).

## 4) Acceptance Criteria
- Zero uncaught errors; pixel-stable layout.
- A11Y AAA automated + manual keyboard pass.
- Offline load verified; exports valid; cross-population functional.

## 5) Test Matrix (minimum)
- Boot, Lookup, Bulk, Enrichment, Search, Export, Offline, A11Y.

## 6) Deliverables
- Keep v1.2 HTML intact; add new JS under `/assets/js/` only.
- `service-worker.js` + registration.
- Update `CHANGELOG.md` and `GAP_REPORT.md`.
- Optionally emit a monolithic build that inlines assets without altering semantics.

## 7) Hand-off Instruction (paste to Agent Mode)
Use this ZIP as the **UI reference**. Follow this playbook exactly. Do not alter DOM IDs/classes/ARIA. Implement v2.0 features via adapters and new JS files only. Provide diffs + screenshots before any DOM changes.
