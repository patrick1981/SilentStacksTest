# SilentStacks Changelog

## [2.0.4] – 2025-08-09

### Added
- Offline fallback page `offline.html` with accessible, responsive layout.
- Enhanced Offline Manager with Background Sync + BroadcastChannel for multi-tab flush.
- GitHub Pages–aware Service Worker that auto-detects base path and safely precaches.
- Offline navigation fallback with network-first strategy for HTML.

### Changed
- Scripts now load at end of `<body>` with `defer` to improve paint and avoid race conditions.
- Module definitions in `core/bootstrap.js` aligned with actual `modules/**` structure.

### Fixed
- Crash due to empty `offline-manager.js` and early module access.
- SW install failures from 404s in `APP_SHELL` (now safely skipped).
